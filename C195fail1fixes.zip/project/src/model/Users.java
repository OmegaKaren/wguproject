package model;
/**
 * A model class that creates the objects for Users and defines the getters to access those objects when you need it.
 */
public class Users {

    private int id;
    private String user_name;
    private String password;



    public Users(int id, String user_name, String password){
        this.id = id;
        this.user_name = user_name;
        this.password = password;
    }


    public int getId() { return id; }

    public String getUser_name() { return user_name; }

    public String getPassword() { return password; }


    @Override
    public String toString() {return user_name; }
}
