package model;

import java.sql.Time;
import java.sql.Timestamp;
/**
 * A model class that creates the objects for Customers and defines the getters to access those objects when you need it.
 */
public class Customers {

    private int customerID;
    private String customerName;
    private String address;
    private String postalCode;
    private String phone;
    private Timestamp createDate;
    private String createdBy;
    private Timestamp lastUpdate;
    private String lastUpdatedBy;
    private int divisionID;

    public Customers(int customerID, String customerName, String address, String postalCode, String phone, Timestamp createDate, String createdBy, Timestamp lastUpdate, String lastUpdatedBy, int divisionID){
        this.customerID = customerID;
        this.customerName = customerName;
        this.address = address;
        this.postalCode = postalCode;
        this.phone = phone;
        this.createDate = createDate;
        this.createdBy = createdBy;
        this.lastUpdate = lastUpdate;
        this.lastUpdatedBy = lastUpdatedBy;
        this.divisionID = divisionID;
    }

    public int getCustomerID() { return customerID; }
    public void setID(int customerID) { this.customerID = customerID;}

    public String getCustomerName() { return customerName; }

    public String getAddress() { return  address; }

    public String getPostalCode() { return postalCode; }

    public String getPhone() { return phone; }

    public Timestamp getCreateDate() { return  createDate; }

    public String getCreatedBy() { return createdBy; }

    public Timestamp getLastUpdate() { return lastUpdate; }

    public String getLastUpdatedBy() { return lastUpdatedBy;}

    public int getDivisionID() { return divisionID; }

    @Override
    public String toString() {
        return customerName;
    }
}
