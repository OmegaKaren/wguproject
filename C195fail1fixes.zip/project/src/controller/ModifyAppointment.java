package controller;

import DBAccess.DBAppointments;
import DBAccess.DBContacts;
import DBAccess.DBCustomers;
import DBAccess.DBUsers;
import Database.DBConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.*;

import javax.swing.*;
import java.awt.*;
import java.net.URL;
import java.sql.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ResourceBundle;

/**
 * This class allows the abililty to modify pre-existing appoinments.
 */
public class ModifyAppointment implements Initializable {
    public TextField appointmentID;
    public TextField title;
    public TextField description;
    public TextField location;
    public TextField contact;
    public TextField type;
    public DatePicker startDate;
    public DatePicker endDate;
    public Button save;
    public Button cancel;
    public MenuButton country;
    public TextField userID;
    public TextField CustomerID;
    public TextField UserID;
    public DatePicker createDate;
    public DatePicker StartDate;
    public DatePicker EndDate;
    public Spinner startHours;
    public Spinner startMinutes;
    public Spinner endHours;
    public Spinner endMinute;
    public ComboBox<Customers> customerCombo;
    public ComboBox <Contacts> contactCombo;
    public ComboBox <Users> userCombo;
    public RadioButton newTime;
    public RadioButton sameTime;
    private boolean flag = false;

    /**
     * This sets appointment disables appointmentID as well as sets customer and contact combo to
     * show all customers and contacts. I also created a spinner for inputting time.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        appointmentID.setDisable(true);
        customerCombo.setItems(DBCustomers.getAllCustomers());
        contactCombo.setItems(DBContacts.getAllContacts());
        SpinnerValueFactory<Integer> sHours = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 24);
        SpinnerValueFactory<Integer> sminutes = new SpinnerValueFactory.IntegerSpinnerValueFactory(0,59);
        SpinnerValueFactory<Integer> eHours = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 24);
        SpinnerValueFactory<Integer> eminutes = new SpinnerValueFactory.IntegerSpinnerValueFactory(0,59);



        startHours.setValueFactory(sHours);
        startMinutes.setValueFactory(sminutes);
        endHours.setValueFactory(eHours);
        endMinute.setValueFactory(eminutes);


    }

    /**
     * I created a trasferdata method to transfer selected data to the current scene to be updated.
     * @param data
     */

    public void transferData(Appointments data){
        SpinnerValueFactory<Integer> sHours = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 24);
        SpinnerValueFactory<Integer> sminutes = new SpinnerValueFactory.IntegerSpinnerValueFactory(0,59);
        SpinnerValueFactory<Integer> eHours = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 24);
        SpinnerValueFactory<Integer> eminutes = new SpinnerValueFactory.IntegerSpinnerValueFactory(0,59);



        startHours.setValueFactory(sHours);
        startMinutes.setValueFactory(sminutes);
        endHours.setValueFactory(eHours);
        endMinute.setValueFactory(eminutes);



        appointmentID.setText(Integer.toString(data.getAppointmentID()));

        String sql = "SELECT * FROM Appointments WHERE Appointment_ID='"+appointmentID.getText()+"'";

        try {
            PreparedStatement ps = DBConnection.getConn().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while(rs.next()){
//
                title.setText(data.getTitle());
                description.setText(data.getDescription());
                location.setText(data.getLocation());
                type.setText(data.getType());
                StartDate.setValue(data.getStart().toLocalDateTime().toLocalDate());
                EndDate.setValue(data.getEnd().toLocalDateTime().toLocalDate());
                sHours.setValue(data.getStart().toLocalDateTime().getHour());
                startHours.setValueFactory(sHours);
                sminutes.setValue(data.getStart().toLocalDateTime().getMinute());
                startMinutes.setValueFactory(sminutes);
                eHours.setValue(data.getEnd().toLocalDateTime().getHour());
                endHours.setValueFactory(eHours);
                eminutes.setValue(data.getEnd().toLocalDateTime().getMinute());
                endMinute.setValueFactory(eminutes);



            customerCombo.setValue(DBCustomers.getCustomers(data.getCustomerID()));

            contactCombo.setValue(DBContacts.getContacts(data.getContactID()));

            userCombo.setValue(DBUsers.getUsers(data.getUserID()));

            




            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }


    /**
     * here I create a Timestamp, convert it to eastern time and then compare it to localtime for time conversion, I then verify
     * if the appointment trying to be created is within business hours, if not it will raise and error. If it is within business hours
     * I then make a sql statemnt and execute it. If there is a pre-existing appointment during that time it will raise an
     * error and make you select another time.
     * @param actionEvent
     * @throws SQLException
     */
    public void savebutton(ActionEvent actionEvent) throws SQLException {
        Timestamp dateTime = Timestamp.valueOf(StartDate.getValue() + " " + startHours.getValue() + ":" + startMinutes.getValue() + ":00");
        //turn timestamp into a ZonedDateTime of eastern time
        ZonedDateTime easternStart = dateTime.toInstant().atZone(ZoneId.of("America/New_York"));
        //Then convert that to current localdatetime to compare business hours
        LocalDateTime easternLocalStart = easternStart.toLocalDateTime();
        Timestamp endDateTime = Timestamp.valueOf(EndDate.getValue() + " " + endHours.getValue() + ":" + endMinute.getValue() + ":00");
        ZonedDateTime easternEnd = endDateTime.toInstant().atZone(ZoneId.of("America/New_York"));
        LocalDateTime easternLocalEnd = easternEnd.toLocalDateTime();
        List<Appointments> appointments = DBAppointments.getAllAppointments();

        String sql = "UPDATE Appointments SET Title = ?," +
                "Description = ?," +
                "Location = ?," +
                "Type = ?," +
                "Start = ?," +
                "End = ?," +
                "Last_Update = now() ," +
                "Customer_ID = ?," +
                "Contact_ID = ?," +
                "User_ID = ? WHERE Appointment_ID = ?";
        if (easternLocalStart.getHour() < 8 || easternLocalStart.getHour() > 22 || easternLocalEnd.getHour() < 8 || easternLocalEnd.getHour() > 22) {
            Alert hoursAlert = new Alert(Alert.AlertType.ERROR);
            hoursAlert.setHeaderText("Error");
            hoursAlert.setContentText("Business hours are between 08:00 and 22:00 you cannot schedule an appoint outside of those times.");
            hoursAlert.showAndWait();
            return;
        }

        PreparedStatement stmt = DBConnection.getConn().prepareStatement(sql);
        int parameterIndex = 0;
        stmt.setString(++parameterIndex, title.getText());
        stmt.setString(++parameterIndex, description.getText());
        stmt.setString(++parameterIndex, location.getText());
        stmt.setString(++parameterIndex, type.getText());
        stmt.setTimestamp(++parameterIndex, dateTime);
        stmt.setTimestamp(++parameterIndex, endDateTime);
        stmt.setInt(++parameterIndex, customerCombo.getValue().getCustomerID());
        stmt.setInt(++parameterIndex, contactCombo.getValue().getId());
        stmt.setInt(++parameterIndex, userCombo.getValue().getId());
        stmt.setInt(++parameterIndex, Integer.parseInt(appointmentID.getText()));
        if(sameTime.isSelected()){
            stmt.executeUpdate();

            Stage stage = (Stage) save.getScene().getWindow();
            stage.close();
        }else
        // added lambda function to improve my conditional for appointment overlapping.
        /**
         * @lamda added lambda function to improve my conditional for appointment overlapping.
         */
        if (appointments.stream().anyMatch(a -> (dateTime.before(a.getEnd()) && endDateTime.after(a.getStart())) || (dateTime.toLocalDateTime().equals(a.getEnd()) && endDateTime.toLocalDateTime().equals(a.getStart())))) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("warning");
            alert.setContentText("This customer has overlapping appointments " + easternStart.toLocalDateTime()+ " " + easternEnd.toLocalDateTime());
            alert.showAndWait();
            return;


        }else {
            if (!this.flag) {
                stmt.executeUpdate();

                Stage stage = (Stage) save.getScene().getWindow();
                stage.close();
            }

        }
    }

    /**
     * closes screen without making any changes.
     * @param actionEvent
     */
        public void cancelButton(ActionEvent actionEvent) {

        Stage stage = (Stage) cancel.getScene().getWindow();
        stage.close();
    }

    public void countryButton(ActionEvent actionEvent) {
    }

    public void createDateButton(ActionEvent actionEvent) {
    }


    public void newTimeButton(ActionEvent actionEvent) {
    }

    public void sameTimeButton(ActionEvent actionEvent) {

    }
}
