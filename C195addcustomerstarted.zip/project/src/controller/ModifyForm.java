package controller;

import DBAccess.DBDivision;
import Database.DBConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.Appointments;
import model.Customers;
import model.Divisions;

import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

public class ModifyForm implements Initializable {


    public TextField CustomerID;
    public TextField CustomerName;
    public TextField Address;
    public TextField PostalCode;
    public TextField Phone;
    public TextField CreatedBy;
    public DatePicker CreateDate;
    public DatePicker LastUpdate;
    public MenuButton Division;
    public Button save;
    public Button cancel;
    public MenuButton country;
    Mainscreen main;
    DBDivision dbDivision;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        CustomerID.setDisable(true);


    }

    public void transferData(Appointments data) throws SQLException {

        //transfer selected items from appointments tab in main screen and pass customer ID to modify form
        CustomerID.setText(Integer.toString(data.getCustomerID()));
        //create a sql query for that passed customer ID;
        String sql = "SELECT * FROM Customers WHERE Customer_ID='" + CustomerID.getText() + "'";
        PreparedStatement ps = DBConnection.getConn().prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        //return all values from that executed query and set text box to the results.
        if (rs.next()) {
            int customerID = rs.getInt("Customer_ID");
            String customerName = rs.getString("Customer_Name");
            String address = rs.getString("Address");
            String postalCode = rs.getString("Postal_Code");
            String phone = rs.getString("Phone");
            Timestamp createDate = rs.getTimestamp("Create_Date");
            String createdBy = rs.getString("Created_By");
            Timestamp lastUpdate = rs.getTimestamp("Last_Update");
            String lastUpdatedBy = rs.getString("Last_Updated_By");
            int divisionID = rs.getInt("Division_ID");
            Customers c = new Customers(customerID, customerName, address, postalCode, phone, createDate, createdBy, lastUpdate, lastUpdatedBy, divisionID);
            CustomerName.setText(c.getCustomerName());
            Address.setText(c.getAddress());
            PostalCode.setText(c.getPostalCode());
            Phone.setText(c.getPhone());
            LocalDateTime value = createDate.toLocalDateTime();
            CreateDate.setValue(LocalDate.from(value));
            CreatedBy.setText(c.getCreatedBy());
            LocalDateTime val1 = lastUpdate.toLocalDateTime();
            LastUpdate.setValue(LocalDate.from(val1));
            Division.setText(Integer.toString(c.getDivisionID()));

            //create query to specifically output current division name
            String getName = "SELECT * FROM first_level_divisions WHERE Division_ID='" + Division.getText() + "'";
            PreparedStatement getDiv = DBConnection.getConn().prepareStatement(getName);
            System.out.println(getDiv);
            ResultSet divQuery = getDiv.executeQuery();
            //set division name and country
            while (divQuery.next()) {
                String getdivName = divQuery.getString("Division");
                int countryID = divQuery.getInt("Country_ID");
                System.out.println(countryID);
                Division.setText(String.valueOf(getdivName));
                country.setText(String.valueOf(countryID));
                if (country.getText().equals("1")) {
                    country.setText("US");
                }
                if (country.getText().equals("2")) {
                    country.setText("UK");
                }
                if (country.getText().equals("3")) {
                    country.setText("CANADA");
                }

                // create query to show all divisions within country
                String getQuery = "SELECT * FROM first_level_divisions WHERE Country_ID='" + countryID + "'";
                PreparedStatement countryQuery = DBConnection.getConn().prepareStatement(getQuery);
                ResultSet rq = countryQuery.executeQuery();
                if (country.getText().equals("US")) {
                    for (Divisions d : DBDivision.getFirstDivision()) {
                        MenuItem getDivName = new MenuItem(d.getDivision());

                        Division.getItems().addAll(getDivName);
                        getDivName.setOnAction(e -> {
                            Division.setText(String.valueOf(getDivName.getText()));
                        });


                    }


                }
                if (country.getText().equals("UK")) {
                    for (Divisions d : DBDivision.getSecondDivision()) {
                        MenuItem getDivName = new MenuItem(d.getDivision());

                        Division.getItems().addAll(getDivName);
                        getDivName.setOnAction(e -> {
                            Division.setText(String.valueOf(getDivName.getText()));
                        });
                    }
                }

                if (country.getText().equals("CA")){
                    for (Divisions d : DBDivision.getThirdDivision()){
                        MenuItem getDivName = new MenuItem(d.getDivision());

                        Division.getItems().addAll(getDivName);
                        getDivName.setOnAction(e -> {
                            Division.setText(String.valueOf(getDivName.getText()));
                        });
                    }
                }


            }


        }


    }





    public void savebutton(ActionEvent actionEvent) {

        java.sql.Date createDate = java.sql.Date.valueOf(CreateDate.getValue());
        java.sql.Date lastUpdate = java.sql.Date.valueOf(LastUpdate.getValue());

        String sql = "UPDATE Customers SET Customer_Name='"+CustomerName.getText()+"'," +
                " Address='"+Address.getText()+"'," +
                " Postal_Code='"+PostalCode.getText()+"'," +
                " Phone='"+Phone.getText()+"'," +
                " Create_Date='"+createDate+"'," +
                " Created_By='"+CreatedBy.getText()+"'," +
                " Last_Update='"+lastUpdate+"' WHERE Customer_ID='"+CustomerID.getText()+"'";
        try {


            Statement stmt = DBConnection.getConn().createStatement();

            stmt.executeUpdate(sql);

            Stage stage = (Stage) save.getScene().getWindow();
            stage.close();

        } catch (SQLException throwables) {
            throwables.printStackTrace();

        }

    }

    public void cancelButton(ActionEvent actionEvent) {

        Stage stage = (Stage) cancel.getScene().getWindow();
        stage.close();
    }

    public void countryButton(ActionEvent actionEvent) {
    }
}
