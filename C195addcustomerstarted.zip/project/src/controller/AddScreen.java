package controller;

import DBAccess.DBCountries;
import DBAccess.DBDivision;
import Database.DBConnection;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.Countries;
import model.Divisions;

import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

public class AddScreen implements Initializable {
    public Button save;
    public TextField CustomerID;
    public TextField CustomerName;
    public TextField Address;
    public TextField PostalCode;
    public TextField Phone;
    public TextField CreatedBy;
    public DatePicker CreateDate;
    public DatePicker LastUpdate;
    public MenuButton Division;
    public Button cancel;
    public MenuButton country;

    public void savebutton(ActionEvent actionEvent) throws SQLException {
        java.sql.Date createDate = java.sql.Date.valueOf(CreateDate.getValue());
        java.sql.Date lastUpdate = java.sql.Date.valueOf(LastUpdate.getValue());

        String getDivID = "SELECT Division_ID FROM first_level_divisions WHERE Division='"+Division.getText()+"'";
        PreparedStatement ps = DBConnection.getConn().prepareStatement(getDivID);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            int div = rs.getInt("Division_ID");



            String sql = "INSERT INTO Customers (Customer_Name, Address, Postal_Code, Phone, Create_Date, Created_By, Last_Update, Division_ID) VALUES('" + CustomerName.getText() + "', '" + Address.getText() + "', '" + PostalCode.getText() + "', '" + Phone.getText() + "', '" + createDate + "', '" + CreatedBy.getText() + "', '" + lastUpdate + "', '" + div + "'";
            System.out.print(sql);

            try {


                Statement stmt = DBConnection.getConn().prepareStatement(sql);
                stmt.execute(sql);


                Stage stage = (Stage) save.getScene().getWindow();
                stage.close();

            } catch (SQLException throwables) {
                throwables.printStackTrace();

            }
        }
    }



    public void cancelButton(ActionEvent actionEvent) {
        Stage stage = (Stage) cancel.getScene().getWindow();
        stage.close();
    }

    public void countryButton(ActionEvent actionEvent) {

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        for (Countries c : DBCountries.getAllCountries()){
            MenuItem menuItem = new MenuItem(c.getName());

            country.getItems().addAll(menuItem);

           menuItem.setOnAction(e -> {
               country.setText(menuItem.getText());
           });

        }
        for (Divisions d : DBDivision.getAllDivision()){
            MenuItem menuItem = new MenuItem(d.getDivision());
            Division.getItems().addAll(menuItem);

            }
        }




    }

