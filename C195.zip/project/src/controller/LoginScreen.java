package controller;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.effect.SepiaTone;

import java.net.URL;
import java.time.ZoneId;
import java.util.*;

public class LoginScreen implements Initializable {
    public Label location;
    public MenuButton language;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ResourceBundle rb = ResourceBundle.getBundle("src/language_fr.properties", Locale.FRANCE);
        MenuItem english = new MenuItem("English");
        MenuItem french = new MenuItem("French");
        language.getItems().addAll(english, french);
        french.setOnAction(e -> {
            
        });

        // on initialization of the application this code gets the zone id for the system.
        ZoneId z = ZoneId.systemDefault();
        if (String.valueOf(z) != "Europe/Paris"){
            location.setText("America");
            language.setText("English");
        }else {
            location.setText("France");
        }


    }



    public void languageButton(ActionEvent actionEvent) {


    }
}
