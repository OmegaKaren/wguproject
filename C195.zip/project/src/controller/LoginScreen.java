package controller;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.effect.SepiaTone;

import java.net.URL;
import java.time.ZoneId;
import java.util.*;

public class LoginScreen implements Initializable {
    public Label location;
    public MenuButton language;
    public Label username;
    public Label password;
    public Button login;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //takes the system default language and sets all application language to default
        if (String.valueOf(Locale.getDefault()).equals("en_US")){
            language.setText("English");
        }else{
            language.setText("French");


        }
        //Create menu items for language button
        MenuItem english = new MenuItem("English");
        MenuItem french = new MenuItem("French");
        language.getItems().addAll(english, french);
        // creates an event when clicked to set language to french
        french.setOnAction(e -> {
            language.setText("french");
            Locale.setDefault(new Locale("fr", "FR"));
            ResourceBundle rb = ResourceBundle.getBundle("language_files/rb");
            username.setText(rb.getString("username"));
            password.setText(rb.getString("password"));
            english.setText(rb.getString("english"));
            french.setText(rb.getString("french"));
            login.setText(rb.getString("login"));

        });
        //creates an event when clicked to set language to english
        english.setOnAction(e -> {
            language.setText("english");
            Locale.setDefault(new Locale("en", "US"));
            ResourceBundle rb = ResourceBundle.getBundle("language_files/rb");
            username.setText(rb.getString("username"));
            password.setText(rb.getString("password"));
            english.setText(rb.getString("english"));
            french.setText(rb.getString("french"));
            login.setText(rb.getString("login"));

        });


        // on initialization of the application this code gets the zone id for the system.
        ZoneId z = ZoneId.systemDefault();
        location.setText(String.valueOf(z));


    }



    public void languageButton(ActionEvent actionEvent) {


    }
}
