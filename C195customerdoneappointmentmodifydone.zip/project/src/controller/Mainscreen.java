package controller;

import DBAccess.DBAppointments;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Appointments;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class Mainscreen implements Initializable {

    public TableView table;
    public TableColumn appointment_ID;
    public TableColumn title;
    public TableColumn location;
    public TableColumn description;
    public TableColumn type;
    public TableColumn start;
    public TableColumn end;
    public TableColumn createDate;
    public TableColumn createdBy;
    public TableColumn lastUpdate;
    public TableColumn lastUpdatedBy;
    public TableColumn CustomerID;
    public TableColumn userID;
    public TableColumn contactID;
    public RadioButton customers;
    public RadioButton appointments;
    public Button addAppointment;
    public Button modifyAppointment;
    public Button deleteAppointment;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        appointments.fire();



            table.setItems(DBAppointments.getAllAppointments());

            appointment_ID.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
            title.setCellValueFactory(new PropertyValueFactory<>("title"));
            description.setCellValueFactory(new PropertyValueFactory<>("description"));
            location.setCellValueFactory(new PropertyValueFactory<>("location"));
            type.setCellValueFactory(new PropertyValueFactory<>("type"));
            start.setCellValueFactory(new PropertyValueFactory<>("start"));
            end.setCellValueFactory(new PropertyValueFactory<>("end"));
            createDate.setCellValueFactory(new PropertyValueFactory<>("createdDate"));
            createdBy.setCellValueFactory(new PropertyValueFactory<>("createdBy"));
            lastUpdate.setCellValueFactory(new PropertyValueFactory<>("lastUpdate"));
            lastUpdatedBy.setCellValueFactory(new PropertyValueFactory<>("lastUpdatedBy"));
            CustomerID.setCellValueFactory(new PropertyValueFactory<>("customerID"));
            userID.setCellValueFactory(new PropertyValueFactory<>("userID"));
            contactID.setCellValueFactory(new PropertyValueFactory<>("contactID"));




        
    }



    public void deleteCustomerButton(ActionEvent actionEvent) {
    }

    public void table(SortEvent<TableView> tableViewSortEvent) {
    }



    public void modifyButton(ActionEvent actionEvent) {


    }

    public void customersRadioButton(ActionEvent actionEvent)  {

        if (customers.isSelected()){
            try {
                appointments.setSelected(false);
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/mainscreenCustomers.fxml"));
                Parent root = loader.load();

                Stage stage = new Stage();
                stage.setScene(new Scene(root,1526, 800 ));
                stage.setTitle("Customer Table");
                stage.show();
                Stage stage1 = (Stage) customers.getScene().getWindow();
                stage1.close();





            } catch (IOException e) {
                e.printStackTrace();
            }


        }
    }

    public void appointmentsRadioButton(ActionEvent actionEvent) {
    }


    public void createAppointmentButton(ActionEvent actionEvent) {
    }

    public void modifyAppointmentButton(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/modifyAppointment.fxml"));
            Parent root = loader.load();
            Appointments selectedItem = (Appointments) table.getSelectionModel().getSelectedItem();

            ModifyAppointment modifyAppointment = loader.getController();
            modifyAppointment.transferData(selectedItem);


            Stage stage = new Stage();
            stage.setScene(new Scene(root, 1526,800));
            stage.setTitle("Modify Appointment");
            stage.showAndWait();
            table.setItems(DBAppointments.getAllAppointments());

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void deleteAppointmentButton(ActionEvent actionEvent) {
    }
}
