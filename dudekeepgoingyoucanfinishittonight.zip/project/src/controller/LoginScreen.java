package controller;

import Database.DBConnection;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class LoginScreen implements Initializable {
    public Label location;
    public MenuButton language;
    public Button login;
    public Label usernameLabel;
    public Label passwordLabel;
    public TextField username;
    public PasswordField password;
   private ResourceBundle rb = ResourceBundle.getBundle("lang", Locale.getDefault());
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        usernameLabel.setText(rb.getString("username"));
        passwordLabel.setText(rb.getString("password"));
        login.setText(rb.getString("login"));



        // on initialization of the application this code gets the zone id for the system.
        ZoneId z = ZoneId.systemDefault();
        location.setText(String.valueOf(z));


    }



    public void languageButton(ActionEvent actionEvent) {


    }
// create login button for user
    public void login(ActionEvent actionEvent) throws SQLException {
        String sql = "SELECT * FROM Users WHERE User_Name='"+username.getText()+"' and Password='"+password.getText()+"'";
        PreparedStatement ps = DBConnection.getConn().prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        //login successful
        if (rs.next()){
            loginattemptlLog(username.getText(), "success");
            try {
                Locale.setDefault(new Locale("en", "US"));
                Parent root = FXMLLoader.load(getClass().getResource("/view/mainscreenAppointments.fxml"));
                Stage stage = new Stage();
                stage.setTitle("Main Screen");
                stage.setScene(new Scene(root, 1526, 800));
                Stage stage1 = (Stage) login.getScene().getWindow();
                stage1.close();
                stage.show();
                System.out.println(Locale.getDefault());

            } catch (IOException e) {
                e.printStackTrace();
            }
            // login unsuccessful
        }else {
            loginattemptlLog(username.getText(), "failed");
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(rb.getString("error"));
            alert.setContentText(rb.getString("incorrect"));
            Optional<ButtonType> frencherror = alert.showAndWait();


        }




    }
    // Log any attempts when logging in.
    public void loginattemptlLog(String username, String success){
        try{
            FileWriter fw = new FileWriter("login_activity.txt",true);

            //get the current date and time
           DateTimeFormatter dtf =  DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
            LocalDateTime now = LocalDateTime.now();

            fw.write(String.format(username + " " + dtf.format(now) + " " + success + "\n"));

            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
