package model;

import DBAccess.DBContacts;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.Timestamp;

public class Appointments {

    private int appointmentID;
    private String title;
    private String description;
    private String location;
    private String type;
    private Timestamp start;
    private Timestamp end;
    private Timestamp createdDate;
    private String createdBy;
    private Timestamp lastUpdate;
    private String lastUpdatedBy;
    private int customerID;
    private int userID;
    private int contactID;



    private ObservableList<Customers> associatedAppointments = FXCollections.observableArrayList();

    public Appointments(int appointmentID, String title, String description, String location, String type, Timestamp start, Timestamp end, Timestamp createdDate, String createdBy, Timestamp lastUpdate, String lastUpdatedBy, int customerID, int userID, int contactID){
        this.appointmentID = appointmentID;
        this.title = title;
        this.description = description;
        this.location = location;
        this.type = type;
        this.start = start;
        this.end = end;
        this.createdDate = createdDate;
        this.createdBy = createdBy;
        this.lastUpdate = lastUpdate;
        this.lastUpdatedBy = lastUpdatedBy;
        this.customerID = customerID;
        this.userID = userID;
        this.contactID = contactID;
    }




    public int getAppointmentID() { return appointmentID; }
    public void setID(int appointmentID) {this.appointmentID = customerID; }

    public String getTitle() { return title; }

    public String getDescription() { return description; }

    public String getLocation() { return location; }

    public String getType() { return type; }

    public Timestamp getStart() { return start; }

    public Timestamp getEnd() { return end; }

    public Timestamp getCreatedDate() { return createdDate; }

    public String getCreatedBy() { return createdBy; }

    public Timestamp getLastUpdate() { return lastUpdate; }

    public String getLastUpdatedBy() { return lastUpdatedBy; }

    public int getCustomerID() { return customerID; }

    public int getUserID() { return userID; }

    public int getContactID() { return contactID; }

    public String getContactName() {
        Contacts contact = DBContacts.getContacts(contactID);
        return contact.getName();
    }
}
