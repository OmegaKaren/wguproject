package controller;

import DBAccess.DBAppointments;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.SortEvent;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class reportTwo implements Initializable {


    public Button close;
    public TableView table;
    public TableColumn appointment_ID;
    public TableColumn title;
    public TableColumn description;
    public TableColumn type;
    public TableColumn start;
    public TableColumn end;
    public TableColumn contact_name;
    public TableColumn customerID;

    /**
     * Outputs all relevant information for contact appointments in a tableview.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            table.setItems(DBAppointments.getcontactInfo());

            contact_name.setCellValueFactory(new PropertyValueFactory<>("contactName"));
            customerID.setCellValueFactory(new PropertyValueFactory<>("customerID"));
            appointment_ID.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
            title.setCellValueFactory(new PropertyValueFactory<>("title"));
            description.setCellValueFactory(new PropertyValueFactory<>("description"));
            type.setCellValueFactory(new PropertyValueFactory<>("type"));
            start.setCellValueFactory(new PropertyValueFactory<>("start"));
            end.setCellValueFactory(new PropertyValueFactory<>("end"));



        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }

    /**
     * Closes scene
     * @param actionEvent
     */
    public void closeButton(ActionEvent actionEvent) {
        Stage stage = (Stage) close.getScene().getWindow();
        stage.close();
    }

    public void table(SortEvent<TableView> tableViewSortEvent) {
    }
}
