
package controller;

import Database.DBConnection;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * This is the login screen for the application it has an inilizable, login, login attempt log, and read_me.txt methods
 */
public class LoginScreen implements Initializable {
    public Label location;
    public MenuButton language;
    public Button login;
    public Label usernameLabel;
    public Label passwordLabel;
    public TextField username;
    public PasswordField password;
   private ResourceBundle rb = ResourceBundle.getBundle("lang", Locale.getDefault());

    /**
     * I implemented Initializable at the start of the scene to set the username and password labels to the correct value,
     * I also added the path for the application to change the language based on the users language settings.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        usernameLabel.setText(rb.getString("username"));
        passwordLabel.setText(rb.getString("password"));
        login.setText(rb.getString("login"));
        String path = System.getProperty("user.dir");
        readME(path);




        // on initialization of the application this code gets the zone id for the system.
        ZoneId z = ZoneId.systemDefault();
        location.setText(String.valueOf(z));


    }

    /**
     * Creates a login button for the user to access scheduling application. Upon action this code creates a sql query as a string,
     * creates a connection to the database and executes it. Following that, I created a login attempt method that upon succesfully/unsuccessfully loggin in will
     * create a file called login_activity.txt that will display the username,date, time, and status of the login.
     *
     * @param actionEvent
     * @throws SQLException
     */



// create login button for user
    public void login(ActionEvent actionEvent) throws SQLException {
        String sql = "SELECT * FROM Users WHERE User_Name='"+username.getText()+"' and Password='"+password.getText()+"'";
        PreparedStatement ps = DBConnection.getConn().prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        //login successful
        if (rs.next()){
            loginattemptlLog(username.getText(), "success");
            try {
                Locale.setDefault(new Locale("en", "US"));
                Parent root = FXMLLoader.load(getClass().getResource("/view/mainscreenAppointments.fxml"));
                Stage stage = new Stage();
                stage.setTitle("Main Screen");
                stage.setScene(new Scene(root, 1526, 800));
                Stage stage1 = (Stage) login.getScene().getWindow();
                stage1.close();
                stage.show();
                System.out.println(Locale.getDefault());

            } catch (IOException e) {
                e.printStackTrace();
            }
            // login unsuccessful
        }else {
            loginattemptlLog(username.getText(), "failed");
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(rb.getString("error"));
            alert.setContentText(rb.getString("incorrect"));
            Optional<ButtonType> frencherror = alert.showAndWait();


        }




    }

    /**
     * As stated above I created a method to track login information for the users in the application which output a file called
     * login_activity.txt to the root of the projects directory.
     * @param username
     * @param success
     */
    // Log any attempts when logging in.
    public void loginattemptlLog(String username, String success){
        try{
            FileWriter fw = new FileWriter("login_activity.txt",true);

            //get the current date and time
           DateTimeFormatter dtf =  DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
            LocalDateTime now = LocalDateTime.now();

            fw.write(String.format(username + " " + dtf.format(now) + " " + success + "\n"));

            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Here I created a method to create a readme.txt file that will display detailed information about the application such as who created it, the IDE version, and how to run the program.
     * @param directory
     */
   public void readME(String directory){
        try{
            File file = new File(directory+"/readme.txt");
            String idever = System.getProperty("java.version");
            if (!file.exists()){
                file.createNewFile();
            }
            FileWriter writer =  new FileWriter(file);
            writer.write("Title:Performance Assessment:Software II - Advanced Java Concepts (QAM2). The purpose of this project is create a scheduling app that can track customers appointments via a database and show them in an easy to read manner for it users.\n");
            writer.write("Author: Gabriel Mulero Email: gabrielalexandermulero@gmail.com Phone: (817)341-9793 version: v1.0 date: 1/24/2023\n");
            writer.write("IDE version: " + idever + "JavaFX-SDK-17.0.1\n");
            writer.write("To run this program, you simply need to log in with the correct credentials, from there you will be given the ability to create, modify, delete a user record, as well as the ability to create a new user and view reports by clicking their respective tabs.\n");
            writer.write("For the Third report I decided to make the Login_activity.txt file more accessable by adding it as a report as well that is viewable in the application. Simply click on report three in the start of the app to view it. \n");
            writer.write("MySQL Connector driver: v8.0.25");
            writer.close();
            System.out.println("created at " + file.getAbsolutePath());



        } catch (IOException e) {
            e.printStackTrace();
        }
   }

}
