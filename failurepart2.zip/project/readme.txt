Title:Performance Assessment:Software II - Advanced Java Concepts (QAM2). The purpose of this project is create a scheduling app that can track customers appointments via a database and show them in an easy to read manner for it users.
Author: Gabriel Mulero Email: gabrielalexandermulero@gmail.com Phone: (817)341-9793 version: v1.0 date: 1/24/2023
IDE version: 11.0.11JavaFX-SDK-17.0.1
To run this program, you simply need to log in with the correct credentials, from there you will be given the ability to create, modify, delete a user record, as well as the ability to create a new user and view reports by clicking their respective tabs.
For the Third report I decided to make the Login_activity.txt file more accessable by adding it as a report as well that is viewable in the application. Simply click on report three in the start of the app to view it. 
MySQL Connector driver: v8.0.25