package controller;

import DBAccess.DBAppointments;
import DBAccess.DBContacts;
import DBAccess.DBCustomers;
import DBAccess.DBUsers;
import Database.DBConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.*;

import java.awt.*;
import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

public class ModifyAppointment implements Initializable {
    public TextField appointmentID;
    public TextField title;
    public TextField description;
    public TextField location;
    public TextField contact;
    public TextField type;
    public DatePicker startDate;
    public DatePicker endDate;
    public Button save;
    public Button cancel;
    public MenuButton country;
    public TextField userID;
    public TextField CustomerID;
    public TextField UserID;
    public DatePicker createDate;
    public DatePicker StartDate;
    public DatePicker EndDate;
    public Spinner startHours;
    public Spinner startMinutes;
    public Spinner endHours;
    public Spinner endMinute;
    public ComboBox<Customers> customerCombo;
    public ComboBox <Contacts> contactCombo;
    public ComboBox <Users> userCombo;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        appointmentID.setDisable(true);
        customerCombo.setItems(DBCustomers.getAllCustomers());
        contactCombo.setItems(DBContacts.getAllContacts());
        SpinnerValueFactory<Integer> sHours = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 24);
        SpinnerValueFactory<Integer> sminutes = new SpinnerValueFactory.IntegerSpinnerValueFactory(0,59);
        SpinnerValueFactory<Integer> eHours = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 24);
        SpinnerValueFactory<Integer> eminutes = new SpinnerValueFactory.IntegerSpinnerValueFactory(0,59);



        startHours.setValueFactory(sHours);
        startMinutes.setValueFactory(sminutes);
        endHours.setValueFactory(eHours);
        endMinute.setValueFactory(eminutes);


    }

ObservableList<Appointments> appointmentList = FXCollections.observableArrayList();
    public void transferData(Appointments data){
        SpinnerValueFactory<Integer> sHours = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 24);
        SpinnerValueFactory<Integer> sminutes = new SpinnerValueFactory.IntegerSpinnerValueFactory(0,59);
        SpinnerValueFactory<Integer> eHours = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 24);
        SpinnerValueFactory<Integer> eminutes = new SpinnerValueFactory.IntegerSpinnerValueFactory(0,59);



        startHours.setValueFactory(sHours);
        startMinutes.setValueFactory(sminutes);
        endHours.setValueFactory(eHours);
        endMinute.setValueFactory(eminutes);



        appointmentID.setText(Integer.toString(data.getAppointmentID()));

        String sql = "SELECT * FROM Appointments WHERE Appointment_ID='"+appointmentID.getText()+"'";

        try {
            PreparedStatement ps = DBConnection.getConn().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while(rs.next()){
//                int appointmentId = rs.getInt("Appointment_ID");
//                String Title = rs.getString("Title");
//                String Description = rs.getString("Description");
//                String Location = rs.getString("Location");
//                String Type = rs.getString("Type");
//                Timestamp Start = rs.getTimestamp("Start");
//                Timestamp End = rs.getTimestamp("End");
//                Timestamp CreateDate = rs.getTimestamp("Create_Date");
//                String CreatedBy = rs.getString("Created_By");
//                Timestamp lastUpdate = rs.getTimestamp("Last_Update");
//                String lastUpdatedBY = rs.getString("Last_Updated_By");
//                int customerID = rs.getInt("Customer_ID");
//                int userID = rs.getInt("User_ID");
//                int contactID = rs.getInt("Contact_ID");

                //Appointments a = new Appointments(appointmentId, Title, Description, Location, Type, Start, End, CreateDate, CreatedBy, lastUpdate, lastUpdatedBY, customerID, userID, contactID);
               // appointmentList.addAll(a);
                title.setText(data.getTitle());
                description.setText(data.getDescription());
                location.setText(data.getLocation());
                type.setText(data.getType());
                //LocalDateTime value = Start.toLocalDateTime();
                StartDate.setValue(data.getStart().toLocalDateTime().toLocalDate());
                //LocalDateTime value1 = End.toLocalDateTime();
                EndDate.setValue(data.getEnd().toLocalDateTime().toLocalDate());
                sHours.setValue(data.getStart().toLocalDateTime().getHour());
                startHours.setValueFactory(sHours);
                sminutes.setValue(data.getStart().toLocalDateTime().getMinute());
                startMinutes.setValueFactory(sminutes);
                eHours.setValue(data.getEnd().toLocalDateTime().getHour());
                endHours.setValueFactory(eHours);
                eminutes.setValue(data.getEnd().toLocalDateTime().getMinute());
                endMinute.setValueFactory(eminutes);
                //LocalDateTime value2 = CreateDate.toLocalDateTime();
                //createDate.setValue(LocalDate.from(value2));


            customerCombo.setValue(DBCustomers.getCustomers(data.getCustomerID()));

            contactCombo.setValue(DBContacts.getContacts(data.getContactID()));

            userCombo.setValue(DBUsers.getUsers(data.getUserID()));




            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }

    public ObservableList<Contacts> getcontactID(){
        ObservableList<Contacts> ContactID = FXCollections.observableArrayList();

        try{
            String sql = "SELECT * FROM Contacts WHERE Contact_Name='"+contact.getText()+"'";


            PreparedStatement ps = DBConnection.getConn().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()){
                int contactID = rs.getInt("Contact_ID");
                String contactName = rs.getString("Contact_Name");
                String contactEmail = rs.getString("Email");
                Contacts c = new Contacts(contactID, contactName, contactEmail);
                ContactID.add(c);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return ContactID;
    }
/*
    public ObservableList<Customers> getcustomerID(){
        ObservableList<Customers> customerID = FXCollections.observableArrayList();

        try{
            String sql = "SELECT * FROM Customers WHERE Customer_Name='"+CustomerID.getText()+"'";


            PreparedStatement ps = DBConnection.getConn().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()){
                int getcustomerID = rs.getInt("Customer_ID");
                String customerName = rs.getString("Customer_Name");
                String address = rs.getString("Address");
                String postalCode = rs.getString("Postal_Code");
                String phone = rs.getString("Phone");
                Timestamp createDate = rs.getTimestamp("Create_Date");
                String createdBy = rs.getString("Created_By");
                Timestamp lastUpdate = rs.getTimestamp("Last_Update");
                String lastUpdatedBy = rs.getString("Last_Updated_By");
                int divisionID = rs.getInt("Division_ID");
                Customers c = new Customers(getcustomerID, customerName, address, postalCode, phone, createDate, createdBy, lastUpdate, lastUpdatedBy, divisionID);
                customerID.addAll(c);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return customerID;
    }

    public ObservableList<Users> getuserID(){
        ObservableList<Users> theuserID = FXCollections.observableArrayList();

        try{
            String sql = "SELECT * FROM Users WHERE User_Name='"+ UserID.getText()+"'";


            PreparedStatement ps = DBConnection.getConn().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()){
                int userID = rs.getInt("User_ID");
                String userName = rs.getString("User_Name");
                String password = rs.getString("Password");
                Users user = new Users(userID, userName, password);
                theuserID.add(user);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return theuserID;
    }

*/
    public void savebutton(ActionEvent actionEvent) {
        Timestamp dateTime = Timestamp.valueOf(StartDate.getValue() + " " + startHours.getValue() + ":" + startMinutes.getValue() +  ":00");
        Timestamp endDateTime = Timestamp.valueOf(EndDate.getValue() + " " + endHours.getValue() + ":" + endMinute.getValue() + ":00");


                    String sql = "UPDATE Appointments SET Title = ?," +
                            "Description = ?," +
                            "Location = ?," +
                            "Type = ?," +
                            "Start = ?," +
                            "End = ?," +
                            "Last_Update = now() ," +
                            "Customer_ID = ?," +
                            "Contact_ID = ?," +
                            "User_ID = ? WHERE Appointment_ID = ?";

                    try {

                        PreparedStatement stmt = DBConnection.getConn().prepareStatement(sql);
                        int parameterIndex = 0;
                        stmt.setString(++parameterIndex, title.getText());
                        stmt.setString(++parameterIndex, description.getText());
                        stmt.setString(++parameterIndex, location.getText());
                        stmt.setString(++parameterIndex, type.getText());
                        stmt.setTimestamp(++parameterIndex, dateTime);
                        stmt.setTimestamp(++parameterIndex, endDateTime);
                        stmt.setInt(++parameterIndex, customerCombo.getValue().getCustomerID());
                        stmt.setInt(++parameterIndex, contactCombo.getValue().getId());
                        stmt.setInt(++parameterIndex, userCombo.getValue().getId());
                        stmt.setInt(++parameterIndex, Integer.parseInt(appointmentID.getText()));

                        System.out.println(stmt.toString());
                        stmt.executeUpdate();

                        Stage stage = (Stage) save.getScene().getWindow();
                        stage.close();

                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    }


                }





    public void cancelButton(ActionEvent actionEvent) {

        Stage stage = (Stage) cancel.getScene().getWindow();
        stage.close();
    }

    public void countryButton(ActionEvent actionEvent) {
    }

    public void createDateButton(ActionEvent actionEvent) {
    }
}
