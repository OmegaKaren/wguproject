package controller;

import DBAccess.DBAppointments;
import DBAccess.DBCustomers;
import Database.DBConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import javafx.stage.Stage;
import model.Appointments;
import model.Customers;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Optional;
import java.util.ResourceBundle;

public class MainscreenCustomers implements Initializable {
    public Button addCustomer;
    public Button modifyCustomer;
    public Button deleteCustomer;
    public RadioButton customers;
    public RadioButton appointments;
    public TableView table;
    public TableColumn CustomerID;
    public TableColumn CustomerName;
    public TableColumn Address;
    public TableColumn PostalCode;
    public TableColumn Phone;
    public TableColumn CreateDate;
    public TableColumn CreatedBy;
    public TableColumn createDate;
    public TableColumn createdBy;
    public TableColumn lastUpdate;
    public TableColumn lastUpdatedBy;
    public TableColumn DivisionID;

    /**
     * Initializes the table with infromation from DBCustomers.getAllCustomers.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        customers.setSelected(true);

        table.setItems(DBCustomers.getAllCustomers());

        CustomerID.setCellValueFactory(new PropertyValueFactory<>("customerID"));
        CustomerName.setCellValueFactory(new PropertyValueFactory<>("customerName"));
        Address.setCellValueFactory(new PropertyValueFactory<>("address"));
        PostalCode.setCellValueFactory(new PropertyValueFactory<>("postalCode"));
        Phone.setCellValueFactory(new PropertyValueFactory<>("phone"));
        CreateDate.setCellValueFactory(new PropertyValueFactory<>("createDate"));
        createdBy.setCellValueFactory(new PropertyValueFactory<>("createdBy"));
        lastUpdate.setCellValueFactory(new PropertyValueFactory<>("lastUpdate"));
        lastUpdatedBy.setCellValueFactory(new PropertyValueFactory<>("lastUpdatedBy"));
        DivisionID.setCellValueFactory(new PropertyValueFactory<>("divisionID"));




    }



    public void table(SortEvent<TableView> tableViewSortEvent) {
    }

    /**
     * when clicked, this opens a new scene to create a customer and update the customers table.
     * @param actionEvent
     */
    public void addCustomerButton(ActionEvent actionEvent) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/view/CustomerAddScreen.fxml"));
            Stage stage = new Stage();
            stage.setTitle("Add Customer");
            stage.setScene(new Scene(root, 1526, 800));
            stage.showAndWait();
            table.getItems().setAll(DBCustomers.getAllCustomers());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * opens a new scene to modify a pre-existing customer and update the table to the most up-to-date information.
     * @param actionEvent
     */
    public void modifyButton(ActionEvent actionEvent) {

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/modifyCustomersForm.fxml"));
            Parent root = loader.load();
            Customers selectedItem = (Customers) table.getSelectionModel().getSelectedItem();


            ModifyForm modifyForm = loader.getController();
            modifyForm.transferData(selectedItem);


            Stage stage = new Stage();
            stage.setScene(new Scene(root, 1000, 800));
            stage.setTitle("Modify Customer");
            stage.showAndWait();
            table.setItems(DBCustomers.getAllCustomers());


        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Deletes the customer record, if there is a pre-existing appointment, you will not be able to delete the customer.
     * @param actionEvent
     */

    public void deleteCustomerButton(ActionEvent actionEvent) {

        Customers selectedItem = (Customers) table.getSelectionModel().getSelectedItem();
        ObservableList<Appointments> alist = FXCollections.observableArrayList();

        try {
            String sql = "SELECT * FROM Appointments WHERE Customer_ID='"+selectedItem.getCustomerID()+"'";

            PreparedStatement ps = DBConnection.getConn().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int appointmentID = rs.getInt("Appointment_ID");
                String title = rs.getString("Title");
                String description = rs.getString("Description");
                String location = rs.getString("Location");
                String type = rs.getString("Type");
                Timestamp start = rs.getTimestamp("Start");
                Timestamp end = rs.getTimestamp("End");
                Timestamp createDate = rs.getTimestamp("Create_Date");
                String createdBy = rs.getString("Created_By");
                Timestamp lastUpdate = rs.getTimestamp("Last_Update");
                String lastUpdatedBY = rs.getString("Last_Updated_By");
                int customerID = rs.getInt("Customer_ID");
                int userID = rs.getInt("User_ID");
                int contactID = rs.getInt("Contact_ID");
                Appointments a = new Appointments(appointmentID, title, description, location, type, start, end, createDate, createdBy, lastUpdate, lastUpdatedBY, customerID, userID, contactID);
                alist.add(a);

                DBAppointments.deleteApppointments(customerID);
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("CustomerID: " + customerID + " and all related appointments have been deleted.");
                alert.showAndWait();

            }

                String deleteCustomer = "DELETE FROM Customers WHERE Customer_ID='"+selectedItem.getCustomerID()+"'";
                PreparedStatement preparedStatement = DBConnection.getConn().prepareStatement(deleteCustomer);
                preparedStatement.execute();
                table.setItems(DBCustomers.getAllCustomers());





        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

        public void customersRadioButton (ActionEvent actionEvent){
        }

    /**
     * When clicked this will take you back to the appointments section.
     * @param actionEvent
     */

    public void appointmentsRadioButton (ActionEvent actionEvent){
            if (appointments.isSelected()) {
                try {
                    customers.setSelected(false);
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/mainscreenAppointments.fxml"));
                    Parent root = loader.load();

                    Stage stage = new Stage();
                    stage.setScene(new Scene(root, 1526, 800));
                    stage.setTitle("Customer Table");
                    stage.show();
                    Stage stage1 = (Stage) appointments.getScene().getWindow();
                    stage1.close();


                } catch (IOException e) {
                    e.printStackTrace();
                }


            }
        }
    }

