package model;
/**
 * A model class that creates the objects for countries and defines the getters to access those objects when you need it.
 */
public class Countries {

    private int id;
    private String name;

    public Countries(int id, String name){
        this.id = id;
        this.name = name;
    }


    public int getId() { return id; }

    public String getName() {return name; }


    @Override
    public String toString() {
        return name;
    }
}
