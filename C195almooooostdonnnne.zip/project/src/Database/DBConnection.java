package Database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnection {

    private static final String protocol = "jdbc";
    private static final String vendorName = ":mysql";
    private static final String ipAddress = "://localhost:3306/";
    private static final String dbName = "client_schedule";
    private static final String connectionTimeZone = "?connectionTimeZone=SERVER";

    private static final String jdbcURL = protocol + vendorName + ipAddress + dbName + connectionTimeZone;


    private static final String MYSQLJBDCDriver = "com.mysql.cj.jdbc.Driver";

    private static final String username = "sqlUser";
    private static final String dbPass = "Passw0rd!";
    private static Connection conn = null;


    //method to verify connection to database
    public static Connection startConnection() {
        try{
            Class.forName(MYSQLJBDCDriver);
            conn = DriverManager.getConnection(jdbcURL, username, dbPass);
            System.out.println("Connection Successful");

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e){
            e.printStackTrace();
        }
        return conn;
    }

    public static Connection getConn(){
        return  conn;
    }

    public static void closeConnection(){
        try{
            conn.close();
        } catch (Exception e) {
            // do nothing
        }

    }

}

