package controller;

import Database.DBConnection;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.ZoneId;
import java.util.*;

public class LoginScreen implements Initializable {
    public Label location;
    public MenuButton language;
    public Button login;
    public Label usernameLabel;
    public Label passwordLabel;
    public TextField username;
    public PasswordField password;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //takes the system default language and sets all application language to default
        if (String.valueOf(Locale.getDefault()).equals("en_US")){
            language.setText("English");
        }else{
            language.setText("French");


        }
        //Create menu items for language button
        MenuItem english = new MenuItem("English");
        MenuItem french = new MenuItem("French");
        language.getItems().addAll(english, french);
        // creates an event when clicked to set language to french
        french.setOnAction(e -> {
            language.setText("french");
            Locale.setDefault(new Locale("fr", "FR"));
            ResourceBundle rb = ResourceBundle.getBundle("language_files/rb");
            usernameLabel.setText(rb.getString("username"));
            passwordLabel.setText(rb.getString("password"));
            english.setText(rb.getString("english"));
            french.setText(rb.getString("french"));
            login.setText(rb.getString("login"));

        });
        //creates an event when clicked to set language to english
        english.setOnAction(e -> {
            language.setText("english");
            Locale.setDefault(new Locale("en", "US"));
            ResourceBundle rb = ResourceBundle.getBundle("language_files/rb");
            usernameLabel.setText(rb.getString("username"));
            passwordLabel.setText(rb.getString("password"));
            english.setText(rb.getString("english"));
            french.setText(rb.getString("french"));
            login.setText(rb.getString("login"));

        });


        // on initialization of the application this code gets the zone id for the system.
        ZoneId z = ZoneId.systemDefault();
        location.setText(String.valueOf(z));


    }



    public void languageButton(ActionEvent actionEvent) {


    }
// create login button for user
    public void login(ActionEvent actionEvent) throws SQLException {
        String sql = "SELECT * FROM Users WHERE User_Name='"+username.getText()+"' and Password='"+password.getText()+"'";
        PreparedStatement ps = DBConnection.getConn().prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        if (rs.next()){
            try {
                Parent root = FXMLLoader.load(getClass().getResource("/view/mainscreenAppointments.fxml"));
                Stage stage = new Stage();
                stage.setTitle("Main Screen");
                stage.setScene(new Scene(root, 1526, 800));
                Stage stage1 = (Stage) login.getScene().getWindow();
                stage1.close();
                stage.show();
                System.out.println(Locale.getDefault());

            } catch (IOException e) {
                e.printStackTrace();
            }
        }else{
            if (String.valueOf(Locale.getDefault()).equals("fr_FR")){
                ResourceBundle rb = ResourceBundle.getBundle("language_files/rb");
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText(rb.getString("error"));
                alert.setContentText(rb.getString("incorrect"));
                Optional<ButtonType> frencherror = alert.showAndWait();
            }else {
                ResourceBundle rb = ResourceBundle.getBundle("language_files/rb");
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText(rb.getString("error"));
                alert.setContentText(rb.getString("incorrect"));
                Optional<ButtonType> error = alert.showAndWait();

            }

        }




    }
}
