package controller;

import DBAccess.DBAppointments;
import DBAccess.DBCustomers;
import Database.DBConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Appointments;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Optional;
import java.util.ResourceBundle;

public class Mainscreen implements Initializable {

    public TableView table;
    public TableColumn appointment_ID;
    public TableColumn title;
    public TableColumn location;
    public TableColumn description;
    public TableColumn type;
    public TableColumn start;
    public TableColumn end;
    public TableColumn createDate;
    public TableColumn createdBy;
    public TableColumn lastUpdate;
    public TableColumn lastUpdatedBy;
    public TableColumn CustomerID;
    public TableColumn userID;
    public TableColumn contactID;
    public RadioButton customers;
    public RadioButton appointments;
    public Button addAppointment;
    public Button modifyAppointment;
    public Button deleteAppointment;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        appointments.fire();



            table.setItems(DBAppointments.getAllAppointments());

            appointment_ID.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
            title.setCellValueFactory(new PropertyValueFactory<>("title"));
            description.setCellValueFactory(new PropertyValueFactory<>("description"));
            location.setCellValueFactory(new PropertyValueFactory<>("location"));
            type.setCellValueFactory(new PropertyValueFactory<>("type"));
            start.setCellValueFactory(new PropertyValueFactory<>("start"));
            end.setCellValueFactory(new PropertyValueFactory<>("end"));
            createDate.setCellValueFactory(new PropertyValueFactory<>("createdDate"));
            createdBy.setCellValueFactory(new PropertyValueFactory<>("createdBy"));
            lastUpdate.setCellValueFactory(new PropertyValueFactory<>("lastUpdate"));
            lastUpdatedBy.setCellValueFactory(new PropertyValueFactory<>("lastUpdatedBy"));
            CustomerID.setCellValueFactory(new PropertyValueFactory<>("customerID"));
            userID.setCellValueFactory(new PropertyValueFactory<>("userID"));
            contactID.setCellValueFactory(new PropertyValueFactory<>("contactID"));




        
    }



    public void deleteCustomerButton(ActionEvent actionEvent) {
    }

    public void table(SortEvent<TableView> tableViewSortEvent) {
    }



    public void modifyButton(ActionEvent actionEvent) {


    }

    public void customersRadioButton(ActionEvent actionEvent)  {

        if (customers.isSelected()){
            try {
                appointments.setSelected(false);
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/mainscreenCustomers.fxml"));
                Parent root = loader.load();

                Stage stage = new Stage();
                stage.setScene(new Scene(root,1526, 800 ));
                stage.setTitle("Customer Table");
                stage.show();
                Stage stage1 = (Stage) customers.getScene().getWindow();
                stage1.close();





            } catch (IOException e) {
                e.printStackTrace();
            }


        }
    }

    public void appointmentsRadioButton(ActionEvent actionEvent) {
    }


    public void createAppointmentButton(ActionEvent actionEvent) {

        try{
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/addAppointment.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setScene(new Scene(root, 1526, 800));
            stage.showAndWait();
            table.setItems(DBAppointments.getAllAppointments());


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void modifyAppointmentButton(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/modifyAppointment.fxml"));
            Parent root = loader.load();
            Appointments selectedItem = (Appointments) table.getSelectionModel().getSelectedItem();

            ModifyAppointment modifyAppointment = loader.getController();
            modifyAppointment.transferData(selectedItem);


            Stage stage = new Stage();
            stage.setScene(new Scene(root, 1526,800));
            stage.setTitle("Modify Appointment");
            stage.showAndWait();
            table.setItems(DBAppointments.getAllAppointments());

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void deleteAppointmentButton(ActionEvent actionEvent) {
        Appointments selectedItem = (Appointments) table.getSelectionModel().getSelectedItem();
        ObservableList<Appointments> alist = FXCollections.observableArrayList();

        try {
            String sql = "SELECT * FROM Appointments WHERE Customer_ID='" + selectedItem.getCustomerID() + "'";

            PreparedStatement ps = DBConnection.getConn().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int appointmentID = rs.getInt("Appointment_ID");
                String title = rs.getString("Title");
                String description = rs.getString("Description");
                String location = rs.getString("Location");
                String type = rs.getString("Type");
                Timestamp start = rs.getTimestamp("Start");
                Timestamp end = rs.getTimestamp("End");
                Timestamp createDate = rs.getTimestamp("Create_Date");
                String createdBy = rs.getString("Created_By");
                Timestamp lastUpdate = rs.getTimestamp("Last_Update");
                String lastUpdatedBY = rs.getString("Last_Updated_By");
                int customerID = rs.getInt("Customer_ID");
                int userID = rs.getInt("User_ID");
                int contactID = rs.getInt("Contact_ID");
                Appointments a = new Appointments(appointmentID, title, description, location, type, start, end, createDate, createdBy, lastUpdate, lastUpdatedBY, customerID, userID, contactID);
                alist.add(a);

            }
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setHeaderText("Are you sure?");
            alert.setContentText("Are you sure you want to cancel this appointment?");
            Optional<ButtonType> error = alert.showAndWait();
            if (error.get() == ButtonType.OK){
                String delAppointment = "DELETE FROM Appointments WHERE Appointment_ID='"+selectedItem.getCustomerID()+"'";
                PreparedStatement preparedStatement = DBConnection.getConn().prepareStatement(delAppointment);
                preparedStatement.execute();
                table.setItems(DBAppointments.getAllAppointments());
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    }
