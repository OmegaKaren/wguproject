package controller;

import DBAccess.DBAppointments;
import DBAccess.DBCustomers;
import Database.DBConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.Initializable;
import javafx.scene.control.DatePicker;
import javafx.scene.control.MenuButton;
import javafx.scene.control.TextField;
import model.Appointments;
import model.Customers;

import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Locale;
import java.util.ResourceBundle;

public class ModifyForm implements Initializable {


    public TextField CustomerID;
    public TextField CustomerName;
    public TextField Address;
    public TextField PostalCode;
    public TextField Phone;
    public TextField CreatedBy;
    public DatePicker CreateDate;
    public DatePicker LastUpdate;
    public MenuButton Division;
    Mainscreen main;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        CustomerID.setDisable(true);


    }

    public void transferData(Appointments data) throws SQLException {

        CustomerID.setText(Integer.toString(data.getCustomerID()));
        String sql = "SELECT * FROM Customers WHERE Customer_ID='"+CustomerID.getText()+"'";
        PreparedStatement ps = DBConnection.getConn().prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        if (rs.next()){
            int customerID = rs.getInt("Customer_ID");
            String customerName = rs.getString("Customer_Name");
            String address = rs.getString("Address");
            String postalCode = rs.getString("Postal_Code");
            String phone = rs.getString("Phone");
            Timestamp createDate = rs.getTimestamp("Create_Date");
            String createdBy = rs.getString("Created_By");
            Timestamp lastUpdate = rs.getTimestamp("Last_Update");
            String lastUpdatedBy = rs.getString("Last_Updated_By");
            int divisionID = rs.getInt("Division_ID");
            Customers c = new Customers(customerID, customerName, address, postalCode, phone, createDate, createdBy, lastUpdate, lastUpdatedBy, divisionID);
            CustomerName.setText(c.getCustomerName());
            Address.setText(c.getAddress());
            PostalCode.setText(c.getPostalCode());
            Phone.setText(c.getPhone());
            LocalDateTime value = createDate.toLocalDateTime();
            CreateDate.setValue(LocalDate.from(value));
            CreatedBy.setText(c.getCreatedBy());
            LocalDateTime val1 = lastUpdate.toLocalDateTime();
            LastUpdate.setValue(LocalDate.from(val1));




        }





    }




}
