package controller;

import DBAccess.DBAppointments;
import DBAccess.DBUsers;
import Database.DBConnection;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.SortEvent;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Appointments;
import model.Users;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class Mainscreen implements Initializable {
    public Button addCustomer;
    public Button modifyCustomer;
    public Button deleteCustomer;
    public TableView table;
    public TableColumn appointment_ID;
    public TableColumn title;
    public TableColumn location;
    public TableColumn description;
    public TableColumn type;
    public TableColumn start;
    public TableColumn end;
    public TableColumn createDate;
    public TableColumn createdBy;
    public TableColumn lastUpdate;
    public TableColumn lastUpdatedBy;
    public TableColumn CustomerID;
    public TableColumn userID;
    public TableColumn contactID;



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        table.setItems(DBAppointments.getAllAppointments());

        appointment_ID.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
        title.setCellValueFactory(new PropertyValueFactory<>("title"));
        description.setCellValueFactory(new PropertyValueFactory<>("description"));
        location.setCellValueFactory(new PropertyValueFactory<>("location"));
        type.setCellValueFactory(new PropertyValueFactory<>("type"));
        start.setCellValueFactory(new PropertyValueFactory<>("start"));
        end.setCellValueFactory(new PropertyValueFactory<>("end"));
        createDate.setCellValueFactory(new PropertyValueFactory<>("createdDate"));
        createdBy.setCellValueFactory(new PropertyValueFactory<>("createdBy"));
        lastUpdate.setCellValueFactory(new PropertyValueFactory<>("lastUpdate"));
        lastUpdatedBy.setCellValueFactory(new PropertyValueFactory<>("lastUpdatedBy"));
        CustomerID.setCellValueFactory(new PropertyValueFactory<>("customerID"));
        userID.setCellValueFactory(new PropertyValueFactory<>("userID"));
        contactID.setCellValueFactory(new PropertyValueFactory<>("contactID"));



        
    }


    public void addCustomerButton(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/AddScreen.fxml"));
        Parent root = loader.load();

        Stage stage = new Stage();
        stage.setScene(new Scene(root, 1000, 800));
        stage.setTitle("Add customer");
        stage.showAndWait();

    }

    public void deleteCustomerButton(ActionEvent actionEvent) {
    }

    public void table(SortEvent<TableView> tableViewSortEvent) {
    }



    public void modifyButton(ActionEvent actionEvent) {

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/modifyForm.fxml"));
            Parent root = loader.load();
            Appointments selectedItem = (Appointments) table.getSelectionModel().getSelectedItem();


            ModifyForm modifyForm = loader.getController();
            modifyForm.transferData(selectedItem);







            Stage stage = new Stage();
            stage.setScene(new Scene(root, 1000, 800));
            stage.setTitle("Modify Customer");
            stage.showAndWait();




        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }
}
