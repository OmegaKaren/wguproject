package DBAccess;

import Database.DBConnection;
import com.mysql.cj.x.protobuf.MysqlxPrepare;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Divisions;

import java.sql.*;

public class DBDivision {

    public static ObservableList<Divisions> getAllDivision(){

        ObservableList<Divisions> dlist = FXCollections.observableArrayList();

    try {
        String sql = "SELECT * FROM first_level_divisions";

        PreparedStatement ps = DBConnection.getConn().prepareStatement(sql);

        ResultSet rs = ps.executeQuery();

        while(rs.next()){
            int divisionID = rs.getInt("Division_ID");
            String divisionName = rs.getString("Division");
            Timestamp createDate = rs.getTimestamp("Create_Date");
            String createdBy = rs.getString("Created_By");
            Timestamp lastUpdate = rs.getTimestamp("Last_Update");
            String lastUpdatedBy = rs.getString("Last_Updated_By");
            int country_ID = rs.getInt("Country_ID");
            Divisions d = new Divisions(divisionID, divisionName, createDate, createdBy, lastUpdate, lastUpdatedBy, country_ID);
            dlist.add(d);


        }
    } catch (SQLException throwables) {
        throwables.printStackTrace();
    }
    return dlist;
    }

    public static ObservableList<Divisions> getFirstDivision(){

        ObservableList<Divisions> firstDivList = FXCollections.observableArrayList();
        try{
            String sql = "SELECT * FROM first_level_divisions WHERE Country_ID='1'";
            PreparedStatement ps = DBConnection.getConn().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();
            while (rs.next()){
                int divisionID = rs.getInt("Division_ID");
                String divisionName = rs.getString("Division");
                Timestamp createDate = rs.getTimestamp("Create_Date");
                String createdBy = rs.getString("Created_By");
                Timestamp lastUpdate = rs.getTimestamp("Last_Update");
                String lastUpdatedBy = rs.getString("Last_Updated_By");
                int country_ID = rs.getInt("Country_ID");
                Divisions d = new Divisions(divisionID, divisionName, createDate, createdBy, lastUpdate, lastUpdatedBy, country_ID);
                firstDivList.add(d);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return firstDivList;
    }

    public static ObservableList<Divisions> getSecondDivision(){

        ObservableList<Divisions> secondDivList = FXCollections.observableArrayList();

        try {
            String sql = "SELECT * FROM first_level_divisions WHERE Country_ID='2'";

            PreparedStatement ps = DBConnection.getConn().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while(rs.next()){
                int divisionID = rs.getInt("Division_ID");
                String divisionName = rs.getString("Division");
                Timestamp createDate = rs.getTimestamp("Create_Date");
                String createdBy = rs.getString("Created_By");
                Timestamp lastUpdate = rs.getTimestamp("Last_Update");
                String lastUpdatedBy = rs.getString("Last_Updated_By");
                int country_ID = rs.getInt("Country_ID");
                Divisions d = new Divisions(divisionID, divisionName, createDate, createdBy, lastUpdate, lastUpdatedBy, country_ID);
                secondDivList.add(d);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return secondDivList;
    }

    public static ObservableList<Divisions> getThirdDivision(){
        ObservableList<Divisions> thirdDivList = FXCollections.observableArrayList();

        try {
            String sql = "SELECT * FROM first_level_divisions WHERE Country_ID='3'";

            PreparedStatement ps = DBConnection.getConn().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while(rs.next()){
                int divisionID = rs.getInt("Division_ID");
                String divisionName = rs.getString("Division");
                Timestamp createDate = rs.getTimestamp("Create_Date");
                String createdBy = rs.getString("Created_By");
                Timestamp lastUpdate = rs.getTimestamp("Last_Update");
                String lastUpdatedBy = rs.getString("Last_Updated_By");
                int country_ID = rs.getInt("Country_ID");
                Divisions d = new Divisions(divisionID, divisionName, createDate, createdBy, lastUpdate, lastUpdatedBy, country_ID);
                thirdDivList.add(d);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return thirdDivList;
    }
    public static Divisions getDivision(int divisionid){


        try {
            String sql = "SELECT * FROM first_level_divisions WHERE division_ID = ?";

            PreparedStatement ps = DBConnection.getConn().prepareStatement(sql);
            ps.setInt(1, divisionid);

            ResultSet rs = ps.executeQuery();

            while(rs.next()){
                int divisionID = rs.getInt("Division_ID");
                String divisionName = rs.getString("Division");
                Timestamp createDate = rs.getTimestamp("Create_Date");
                String createdBy = rs.getString("Created_By");
                Timestamp lastUpdate = rs.getTimestamp("Last_Update");
                String lastUpdatedBy = rs.getString("Last_Updated_By");
                int country_ID = rs.getInt("Country_ID");
                Divisions d = new Divisions(divisionID, divisionName, createDate, createdBy, lastUpdate, lastUpdatedBy, country_ID);
                return  d;
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return null;
    }
    public static Divisions getDivisionName(String divisionname){


        try {
            String sql = "SELECT * FROM first_level_divisions WHERE Division = ?";

            PreparedStatement ps = DBConnection.getConn().prepareStatement(sql);
            ps.setString(1, divisionname);

            ResultSet rs = ps.executeQuery();

            while(rs.next()){
                int divisionID = rs.getInt("Division_ID");
                String divisionName = rs.getString("Division");
                Timestamp createDate = rs.getTimestamp("Create_Date");
                String createdBy = rs.getString("Created_By");
                Timestamp lastUpdate = rs.getTimestamp("Last_Update");
                String lastUpdatedBy = rs.getString("Last_Updated_By");
                int country_ID = rs.getInt("Country_ID");
                Divisions d = new Divisions(divisionID, divisionName, createDate, createdBy, lastUpdate, lastUpdatedBy, country_ID);
                return  d;
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return null;
    }


}
