package DBAccess;

import Database.DBConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Appointments;
import model.ReportOne;
import model.ReportTwo;

import java.time.ZoneId;
import java.sql.*;

public class DBAppointments {

    public static ObservableList<Appointments> getAllAppointments() {


        ObservableList<Appointments> alist = FXCollections.observableArrayList();
        ZoneId zone = ZoneId.systemDefault();
        try {
            String sql = "SELECT * FROM Appointments AS a INNER JOIN Contacts AS c ON a.Contact_ID = c.Contact_ID";

            PreparedStatement ps = DBConnection.getConn().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int appointmentID = rs.getInt("Appointment_ID");
                String title = rs.getString("Title");
                String description = rs.getString("Description");
                String location = rs.getString("Location");
                String type = rs.getString("Type");
                Timestamp start = rs.getTimestamp("Start");
                Timestamp end = rs.getTimestamp("End");
                Timestamp createDate = rs.getTimestamp("Create_Date");
                String createdBy = rs.getString("Created_By");
                Timestamp lastUpdate = rs.getTimestamp("Last_Update");
                String lastUpdatedBY = rs.getString("Last_Updated_By");
                int customerID = rs.getInt("Customer_ID");
                int userID = rs.getInt("User_ID");
                int contactID = rs.getInt("Contact_ID");
                Appointments a = new Appointments(appointmentID, title, description, location, type, start, end, createDate, createdBy, lastUpdate, lastUpdatedBY, customerID, userID, contactID);
                alist.add(a);
                System.out.println(start.toLocalDateTime());
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return alist;
    }


    public static ObservableList<Appointments> getAppointmentsWeek() {


        ObservableList<Appointments> alist = FXCollections.observableArrayList();

        try {
            String sql = "SELECT * FROM Appointments WHERE WEEK(start) = WEEK(CURRENT_TIMESTAMP())";

            PreparedStatement ps = DBConnection.getConn().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int appointmentID = rs.getInt("Appointment_ID");
                String title = rs.getString("Title");
                String description = rs.getString("Description");
                String location = rs.getString("Location");
                String type = rs.getString("Type");
                Timestamp start = rs.getTimestamp("Start");
                Timestamp end = rs.getTimestamp("End");
                Timestamp createDate = rs.getTimestamp("Create_Date");
                String createdBy = rs.getString("Created_By");
                Timestamp lastUpdate = rs.getTimestamp("Last_Update");
                String lastUpdatedBY = rs.getString("Last_Updated_By");
                int customerID = rs.getInt("Customer_ID");
                int userID = rs.getInt("User_ID");
                int contactID = rs.getInt("Contact_ID");
                Appointments a = new Appointments(appointmentID, title, description, location, type, start, end, createDate, createdBy, lastUpdate, lastUpdatedBY, customerID, userID, contactID);
                alist.add(a);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return alist;
    }

    public static ObservableList<Appointments> getAppointmentsMonth() {


        ObservableList<Appointments> alist = FXCollections.observableArrayList();

        try {
            String sql = "SELECT * FROM Appointments WHERE Month(start) = Month(CURRENT_TIMESTAMP())";

            PreparedStatement ps = DBConnection.getConn().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int appointmentID = rs.getInt("Appointment_ID");
                String title = rs.getString("Title");
                String description = rs.getString("Description");
                String location = rs.getString("Location");
                String type = rs.getString("Type");
                Timestamp start = rs.getTimestamp("Start");
                Timestamp end = rs.getTimestamp("End");
                Timestamp createDate = rs.getTimestamp("Create_Date");
                String createdBy = rs.getString("Created_By");
                Timestamp lastUpdate = rs.getTimestamp("Last_Update");
                String lastUpdatedBY = rs.getString("Last_Updated_By");
                int customerID = rs.getInt("Customer_ID");
                int userID = rs.getInt("User_ID");
                int contactID = rs.getInt("Contact_ID");
                Appointments a = new Appointments(appointmentID, title, description, location, type, start, end, createDate, createdBy, lastUpdate, lastUpdatedBY, customerID, userID, contactID);
                alist.add(a);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return alist;
    }


    public static ObservableList<ReportOne> gettypemonth() throws SQLException {
        ObservableList<ReportOne> monthreport = FXCollections.observableArrayList();
        try {
            String sql = "SELECT \n" +
                    "  DATE_FORMAT(start, '%M') AS month,\n" +
                    "  type,\n" +
                    "  COUNT(*) AS total\n" +
                    "FROM appointments\n" +
                    "GROUP BY \n" +
                    "  DATE_FORMAT(start, '%M'),\n" +
                    "  type\n" +
                    "ORDER BY month desc;";

            PreparedStatement ps = DBConnection.getConn().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String month = rs.getString("month");
                String type = rs.getString("type");
                int total = rs.getInt("total");
                ReportOne r = new ReportOne(type, total, month);
                monthreport.add(r);
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return monthreport;
    }


    public static ObservableList<ReportTwo> getcontactInfo() throws SQLException {
        ObservableList<ReportTwo> Contactreport = FXCollections.observableArrayList();
        try {
            String sql = "SELECT contacts.Contact_Name , Appointment_ID, Title, Description, Type, Start, End from appointments as appointments\n" +
                    "INNER JOIN contacts as contacts on contacts.Contact_ID = appointments.Contact_ID\n" +
                    "order by contacts.Contact_ID";

            PreparedStatement ps = DBConnection.getConn().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String contact = rs.getString("Contact_name");
                int appointmentID = rs.getInt("Appointment_ID");
                String title = rs.getString("Title");
                String type = rs.getString("Type");
                String description = rs.getString("Description");
                Timestamp start = rs.getTimestamp("Start");
                Timestamp end = rs.getTimestamp("End");
                ReportTwo reportTwo = new ReportTwo(contact, appointmentID, title, type, description, start, end);
                Contactreport.add(reportTwo);
            }



        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return Contactreport;
    }










}
