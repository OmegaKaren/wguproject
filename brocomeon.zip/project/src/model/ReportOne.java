package model;

import java.sql.Time;
import java.sql.Timestamp;

public class ReportOne {

    private String type;
    private int total;
    private String month;



    public ReportOne(String type, int total, String month){
        this.month = month;
        this.type = type;
        this.total = total;
    }

public String getMonth(){
        return month;
}

    public String getType() {
        return type;
    }

    public int getTotal(){
        return total;
    }

}
