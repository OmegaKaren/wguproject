package model;


import java.sql.Timestamp;

public class ReportTwo {

    private String contactName;
    private int appointmentID;
    private String title;
    private String type;
    private String description;
    private Timestamp start;
    private Timestamp end;

    public ReportTwo(String contactName, int appointmentID, String title, String type, String description, Timestamp start, Timestamp end){
        this.contactName = contactName;
        this.appointmentID = appointmentID;
        this.title = title;
        this.type = type;
        this.description = description;
        this.start = start;
        this.end = end;
    }

    public String getContactName(){
        return contactName;
    }
    public int getAppointmentID(){
        return appointmentID;
    }

    public String getTitle(){
        return  title;
    }

    public String getType(){
        return type;
    }

    public String getDescription(){
        return description;
    }

    public Timestamp getStart(){
        return start;
    }

    public Timestamp getEnd(){
        return end;
    }
}
