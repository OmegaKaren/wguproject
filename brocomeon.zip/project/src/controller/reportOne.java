package controller;

import DBAccess.DBAppointments;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.ReportOne;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class reportOne implements Initializable {


    public Button reportOne;
    public Button reportTwo;
    public Button reportThree;
    public TableView table;
    public TableColumn column1;
    public TableColumn column2;
    public TextField janType;
    public TextField janTotal;
    public TextField febType;
    public TextField marchType;
    public TextField aprilType;
    public TextField mayType;
    public TextField junType;
    public TextField julyType;
    public TextField augType;
    public TextField sepType;
    public TextField OctType;
    public TextField novType;
    public TextField decType;
    public TextField febTotal;
    public TextField marchTotal;
    public TextField aprilTotal;
    public TextField mayTotal;
    public TextField junTotal;
    public TextField julyTotal;
    public TextField augTotal;
    public TextField septTotal;
    public TextField octTotal;
    public TextField novTotal;
    public TextField decTotal;
    public TableColumn month;
    public TableColumn type;
    public TableColumn total;
    public TextArea monthsTotal;
    public Button close;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            ObservableList<ReportOne> total = DBAppointments.gettypemonth();
            for (ReportOne r : total){
                monthsTotal.appendText("Month: " + "  " +  r.getMonth() + " Type: " + "  " + r.getType() + " Total: " + "  " + r.getTotal()+"\n");
            }
            monthsTotal.setEditable(false);

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }



    public void reportTwoButton(ActionEvent actionEvent) {
    }

    public void reportThreeButton(ActionEvent actionEvent) {
    }

    public void closeButton(ActionEvent actionEvent) {
        Stage stage = (Stage) close.getScene().getWindow();
        stage.close();
    }
}
