package controller;

import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class reportThree implements Initializable {
    public TableView table;
    public TextArea loginattempts;
    public Button close;
    private Object BufferedReader;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            BufferedReader br = new BufferedReader(new FileReader("login_activity.txt"));


            String line;
            while ((line = br.readLine()) != null) {
                // Split the line into an array of strings
                String[] rows = line.split(",");

                // Add each element in the array to the table
                for (String r : rows) {
                    loginattempts.setText(loginattempts.getText() + r + "\n");
                }
            }

// Close the BufferedReader
            br.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void closeButton(ActionEvent actionEvent) {
        Stage stage = (Stage) close.getScene().getWindow();
        stage.close();
    }
}
