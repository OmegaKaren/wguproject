package controller;

import DBAccess.DBCountries;
import DBAccess.DBDivision;
import Database.DBConnection;
import com.mysql.cj.x.protobuf.MysqlxPrepare;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.Appointments;
import model.Customers;
import model.Divisions;

import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

public class ModifyForm implements Initializable {


    public TextField CustomerID;
    public TextField CustomerName;
    public TextField Address;
    public TextField PostalCode;
    public TextField Phone;
    public TextField CreatedBy;
    public DatePicker CreateDate;
    public DatePicker LastUpdate;
    public MenuButton Division;
    public Button save;
    public Button cancel;

    public TextField lastUpdatedBY;
    public ComboBox country;
    public ComboBox division;
    Mainscreen main;
    DBDivision dbDivision;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        CustomerID.setDisable(true);
        country.setItems(DBCountries.getAllCountries());





    }

    public void transferData(Customers data) throws SQLException {

        //transfer selected items from appointments tab in main screen and pass customer ID to modify form
        CustomerID.setText(Integer.toString(data.getCustomerID()));
        //create a sql query for that passed customer ID;
        String sql = "SELECT * FROM Customers WHERE Customer_ID='" + CustomerID.getText() + "'";
        PreparedStatement ps = DBConnection.getConn().prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        //return all values from that executed query and set text box to the results.
        if (rs.next()) {
            int customerID = rs.getInt("Customer_ID");
            String customerName = rs.getString("Customer_Name");
            String address = rs.getString("Address");
            String postalCode = rs.getString("Postal_Code");
            String phone = rs.getString("Phone");
            Timestamp createDate = rs.getTimestamp("Create_Date");
            String createdBy = rs.getString("Created_By");
            Timestamp lastUpdate = rs.getTimestamp("Last_Update");
            String lastUpdatedBy = rs.getString("Last_Updated_By");
            int divisionID = rs.getInt("Division_ID");
            Customers c = new Customers(customerID, customerName, address, postalCode, phone, createDate, createdBy, lastUpdate, lastUpdatedBy, divisionID);
            CustomerName.setText(c.getCustomerName());
            Address.setText(c.getAddress());
            PostalCode.setText(c.getPostalCode());
            Phone.setText(c.getPhone());
            LocalDateTime value = createDate.toLocalDateTime();
            CreateDate.setValue(LocalDate.from(value));
            CreatedBy.setText(c.getCreatedBy());
            LocalDateTime val1 = lastUpdate.toLocalDateTime();
            LastUpdate.setValue(LocalDate.from(val1));
            lastUpdatedBY.setText(lastUpdatedBy);
            division.setValue(DBDivision.getDivision(data.getDivisionID()));

            country.setValue(DBDivision.getDivision(data.getDivisionID()).getCountryID());

            if (country.getValue().equals(1)){
                country.setValue(DBCountries.getCountry(1).getName());
                division.setItems(DBDivision.getFirstDivision());
            } else if (country.getValue().equals(2)){
                country.setValue(DBCountries.getCountry(2).getName());
                division.setItems(DBDivision.getSecondDivision());

            }else{
                country.setValue(DBCountries.getCountry(3).getName());
                division.setItems(DBDivision.getThirdDivision());
            }



        }


    }

 public  ObservableList<Divisions> getDivID(){
        ObservableList<Divisions> dID = FXCollections.observableArrayList();

        try{
            String sql = "SELECT * FROM first_level_divisions WHERE Division='"+ Division.getText()+"'";

            PreparedStatement ps = DBConnection.getConn().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()){
                int divisionID = rs.getInt("Division_ID");
                String divisionName = rs.getString("Division");
                Timestamp createDate = rs.getTimestamp("Create_Date");
                String createdBy = rs.getString("Created_By");
                Timestamp lastUpdate = rs.getTimestamp("Last_Update");
                String lastUpdatedBy = rs.getString("Last_Updated_By");
                int country_ID = rs.getInt("Country_ID");
                Divisions d = new Divisions(divisionID, divisionName, createDate, createdBy, lastUpdate, lastUpdatedBy, country_ID);
                dID.add(d);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return dID;
 }



    public void savebutton(ActionEvent actionEvent) {
        try {
            division.setValue(DBDivision.getDivisionName(division.getValue().toString()).getDivisionID());


            String sql = "UPDATE Customers SET CUSTOMER_NAME = ?," +
                    "Address = ?," +
                    "Postal_Code = ?," +
                    "Phone = ?," +
                    "Create_Date = NOW()," +
                    "Created_By = ?, " +
                    "Last_Update = NOW()," +
                    "Last_Updated_By = ?," +
                    "Division_ID = ? WHERE Customer_ID = ?";

            PreparedStatement stmt = DBConnection.getConn().prepareStatement(sql);
            int parameterIndex = 0;
            stmt.setString(++parameterIndex, CustomerName.getText());
            stmt.setString(++parameterIndex, Address.getText());
            stmt.setString(++parameterIndex, PostalCode.getText());
            stmt.setString(++parameterIndex, Phone.getText());
            stmt.setString(++parameterIndex, CreatedBy.getText());
            stmt.setString(++parameterIndex, lastUpdatedBY.getText());
            stmt.setInt(++parameterIndex, Integer.parseInt(division.getValue().toString()));
            stmt.setInt(++parameterIndex, Integer.parseInt(CustomerID.getText()));

            stmt.executeUpdate();
            Stage stage = (Stage) save.getScene().getWindow();
            stage.close();
        } catch (Exception e) {
            e.printStackTrace();
            }


    }



    public void cancelButton(ActionEvent actionEvent) {

        Stage stage = (Stage) cancel.getScene().getWindow();
        stage.close();
    }

    public void countryButton(ActionEvent actionEvent) {
        if (country.getValue().toString().equals("U.S")){
            division.setItems(DBDivision.getFirstDivision());
        }else if (country.getValue().toString().equals("UK")){
            division.setItems(DBDivision.getSecondDivision());
        }else {
            division.setItems(DBDivision.getThirdDivision());
        }
    }

    public void divisionButton(ActionEvent actionEvent) {

    }
}
