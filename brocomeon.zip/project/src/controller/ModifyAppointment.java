package controller;

import DBAccess.DBAppointments;
import DBAccess.DBContacts;
import DBAccess.DBCustomers;
import DBAccess.DBUsers;
import Database.DBConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.*;

import java.awt.*;
import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ResourceBundle;

public class ModifyAppointment implements Initializable {
    public TextField appointmentID;
    public TextField title;
    public TextField description;
    public TextField location;
    public TextField contact;
    public TextField type;
    public DatePicker startDate;
    public DatePicker endDate;
    public Button save;
    public Button cancel;
    public MenuButton country;
    public TextField userID;
    public TextField CustomerID;
    public TextField UserID;
    public DatePicker createDate;
    public DatePicker StartDate;
    public DatePicker EndDate;
    public Spinner startHours;
    public Spinner startMinutes;
    public Spinner endHours;
    public Spinner endMinute;
    public ComboBox<Customers> customerCombo;
    public ComboBox <Contacts> contactCombo;
    public ComboBox <Users> userCombo;
    private boolean flag = false;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        appointmentID.setDisable(true);
        customerCombo.setItems(DBCustomers.getAllCustomers());
        contactCombo.setItems(DBContacts.getAllContacts());
        SpinnerValueFactory<Integer> sHours = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 24);
        SpinnerValueFactory<Integer> sminutes = new SpinnerValueFactory.IntegerSpinnerValueFactory(0,59);
        SpinnerValueFactory<Integer> eHours = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 24);
        SpinnerValueFactory<Integer> eminutes = new SpinnerValueFactory.IntegerSpinnerValueFactory(0,59);



        startHours.setValueFactory(sHours);
        startMinutes.setValueFactory(sminutes);
        endHours.setValueFactory(eHours);
        endMinute.setValueFactory(eminutes);


    }


    public void transferData(Appointments data){
        SpinnerValueFactory<Integer> sHours = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 24);
        SpinnerValueFactory<Integer> sminutes = new SpinnerValueFactory.IntegerSpinnerValueFactory(0,59);
        SpinnerValueFactory<Integer> eHours = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 24);
        SpinnerValueFactory<Integer> eminutes = new SpinnerValueFactory.IntegerSpinnerValueFactory(0,59);



        startHours.setValueFactory(sHours);
        startMinutes.setValueFactory(sminutes);
        endHours.setValueFactory(eHours);
        endMinute.setValueFactory(eminutes);



        appointmentID.setText(Integer.toString(data.getAppointmentID()));

        String sql = "SELECT * FROM Appointments WHERE Appointment_ID='"+appointmentID.getText()+"'";

        try {
            PreparedStatement ps = DBConnection.getConn().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while(rs.next()){
//
                title.setText(data.getTitle());
                description.setText(data.getDescription());
                location.setText(data.getLocation());
                type.setText(data.getType());
                //LocalDateTime value = Start.toLocalDateTime();
                StartDate.setValue(data.getStart().toLocalDateTime().toLocalDate());
                //LocalDateTime value1 = End.toLocalDateTime();
                EndDate.setValue(data.getEnd().toLocalDateTime().toLocalDate());
                sHours.setValue(data.getStart().toLocalDateTime().getHour());
                startHours.setValueFactory(sHours);
                sminutes.setValue(data.getStart().toLocalDateTime().getMinute());
                startMinutes.setValueFactory(sminutes);
                eHours.setValue(data.getEnd().toLocalDateTime().getHour());
                endHours.setValueFactory(eHours);
                eminutes.setValue(data.getEnd().toLocalDateTime().getMinute());
                endMinute.setValueFactory(eminutes);
                //LocalDateTime value2 = CreateDate.toLocalDateTime();
                //createDate.setValue(LocalDate.from(value2));


            customerCombo.setValue(DBCustomers.getCustomers(data.getCustomerID()));

            contactCombo.setValue(DBContacts.getContacts(data.getContactID()));

            userCombo.setValue(DBUsers.getUsers(data.getUserID()));




            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }



    public void savebutton(ActionEvent actionEvent) throws SQLException {
        Timestamp dateTime = Timestamp.valueOf(StartDate.getValue() + " " + startHours.getValue() + ":" + startMinutes.getValue() + ":00");
        Timestamp endDateTime = Timestamp.valueOf(EndDate.getValue() + " " + endHours.getValue() + ":" + endMinute.getValue() + ":00");
        int starthour = (Integer) startHours.getValue();
        int endhour = (Integer) endHours.getValue();
        List<Appointments> appointments = DBAppointments.getAllAppointments();

        String sql = "UPDATE Appointments SET Title = ?," +
                "Description = ?," +
                "Location = ?," +
                "Type = ?," +
                "Start = ?," +
                "End = ?," +
                "Last_Update = now() ," +
                "Customer_ID = ?," +
                "Contact_ID = ?," +
                "User_ID = ? WHERE Appointment_ID = ?";
        if (starthour < 8 || starthour > 22 || endhour < 8 || endhour > 22) {
            Alert hoursAlert = new Alert(Alert.AlertType.ERROR);
            hoursAlert.setHeaderText("Error");
            hoursAlert.setContentText("Business hours are between 08:00 and 22:00 you cannot schedule an appoint outside of those times.");
            hoursAlert.showAndWait();
            return;
        }

        PreparedStatement stmt = DBConnection.getConn().prepareStatement(sql);
        int parameterIndex = 0;
        stmt.setString(++parameterIndex, title.getText());
        stmt.setString(++parameterIndex, description.getText());
        stmt.setString(++parameterIndex, location.getText());
        stmt.setString(++parameterIndex, type.getText());
        stmt.setTimestamp(++parameterIndex, dateTime);
        stmt.setTimestamp(++parameterIndex, endDateTime);
        stmt.setInt(++parameterIndex, customerCombo.getValue().getCustomerID());
        stmt.setInt(++parameterIndex, contactCombo.getValue().getId());
        stmt.setInt(++parameterIndex, userCombo.getValue().getId());
        stmt.setInt(++parameterIndex, Integer.parseInt(appointmentID.getText()));
        if (appointments != null) {
            appointments.stream()

                    // .map(b -> System.out.println((Timestamp)b.getEnd()))
                    .filter(a -> (dateTime.before(a.getEnd()) && endDateTime.after(a.getStart())) || (dateTime.toLocalDateTime().equals(a.getEnd()) && endDateTime.toLocalDateTime().equals(a.getStart())))
                    .findAny()
                    .ifPresent(a -> {
                        this.flag = true;
                        Alert overlapping = new Alert(Alert.AlertType.ERROR);
                        overlapping.setContentText("This customer has overlapping appointments" + a.getEnd() + " " + a.getStart() + " " + dateTime + " " + endDateTime);
                        overlapping.showAndWait();
                    });
        }
        try {
            if (!this.flag) {
                stmt.executeUpdate();

                Stage stage = (Stage) save.getScene().getWindow();
                stage.close();
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }


        public void cancelButton(ActionEvent actionEvent) {

        Stage stage = (Stage) cancel.getScene().getWindow();
        stage.close();
    }

    public void countryButton(ActionEvent actionEvent) {
    }

    public void createDateButton(ActionEvent actionEvent) {
    }
}
