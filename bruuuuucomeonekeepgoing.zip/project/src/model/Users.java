package model;

public class Users {

    private int id;
    private String user_name;
    private String password;



    public Users(int id, String user_name, String password){
        this.id = id;
        this.user_name = user_name;
        this.password = password;
    }


    public int getId() { return id; }

    public String getUser_name() { return user_name; }

    public String getPassword() { return password; }


    @Override
    public String toString() {return user_name; }
}
